package es.ucm.fdi.iw.g06.printopolis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PrintopolisApplicationTests {

	@Test
	void contextLoads() {
	}

}
