package es.ucm.fdi.iw.g06.printopolis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrintopolisApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrintopolisApplication.class, args);
	}

}
